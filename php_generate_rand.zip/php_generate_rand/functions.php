<?php

function gen_using_md5($length = 16){
    $code = md5(mt_rand(0, mt_getrandmax()));
    $code = substr($code, 0, $length - 1);
    return $code;
}


function gen_using_sha1($length = 16){
    $code = sha1(mt_rand(0, mt_getrandmax()));
    $code = substr($code, 0, $length - 1);
    return $code;
}

function gen_using_mt_rand($length = 16){
    $strings = array_merge( range(0,9), range('a','z') );
    $code = [];
     for($i = 0 ;$i < $length ;$i++){
        $code[] = $strings[mt_rand(0, count($strings) - 1)];
     }
    $code = implode('', $code);
    return $code;
}
function gen_using_random_int($length = 16){
    $strings = array_merge( range(0,9), range('a','z') );
    $code = [];
     for($i = 0 ;$i < $length ;$i++){
        $code[] = $strings[random_int(0, count($strings) - 1)];
     }
    $code = implode('', $code);
    return $code;
}
function gen_using_rand($length = 16){
    $strings = array_merge( range(0,9), range('a','z') );
    $code = [];
     for($i = 0 ;$i < $length ;$i++){
        $code[] = $strings[rand(0, count($strings) - 1)];
     }
    $code = implode('', $code);
    return $code;
}

function gen_using_shuffle($length = 16){
    $strings = array_merge( range(0,9), range('a','z') );
    shuffle($strings);
    $strings = implode("", $strings);
    $code = substr($strings, 0, $length);
    return $code;
}
function gen_using_uniqid($length = 16){
    $code = uniqid(rand(), true);
    $code = substr($code, 0, $length);
    return $code;
}
function gen_using_bin2hex($length = 16){
    $code = bin2hex(random_bytes($length));
    $code = substr($code, 0, $length);
    return $code;
}