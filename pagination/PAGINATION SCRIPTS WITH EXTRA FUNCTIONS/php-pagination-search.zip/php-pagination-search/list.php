<?php
use Phppot\DataSource;

require_once "perpage.php";
require_once __DIR__ . "/lib/DataSource.php";
$dataSource = new DataSource();

$name = "";
$queryCondition = "";
$paramType = "";
$paramValue = array();
if (! empty($_POST["filter_value"])) {
    $name = $_POST["filter_value"];
    $queryCondition .= " WHERE name LIKE ?";
    $paramType .= 's';
    $paramValue[] = $_POST["filter_value"] . '%';
}

$orderBy = "name";
$order = "asc";
if (! empty($_POST["order_type"])) {
    $order = $_POST["order_type"];
}

$nextOrder = "asc";
if ($order == "asc") {
    $nextOrder = "desc";
}
$query = "SELECT * from tbl_member " . $queryCondition . " ORDER BY " . $orderBy . " " . $order . " ";
$href = 'index.php';
$perPage = 5;
$page = 1;
if (isset($_POST['pagination_offset'])) {
    $page = $_POST['pagination_offset'];
}
$start = ($page - 1) * $perPage;

if ($start < 0)
    $start = 0;

$queryWithLimit = $query . " limit " . $start . "," . $perPage;

$resultpage = $dataSource->select($queryWithLimit, $paramType, $paramValue);

if (! empty($resultpage)) {
    $count = $dataSource->getRecordCount($query, $paramType, $paramValue);

    $resultpage["perpage"] = showperpage($count, $perPage, $href);
}
?>
<?php 
if (! empty($resultpage)) {
    foreach ($resultpage as $k => $v) {
        if (is_numeric($k)) {
            ?>
                            <?php
            $date = $resultpage[$k]["date"];
            $newDate = date("d-m-Y", strtotime($date));
            ?>
<tr>
	<td class="column1"><?php echo $resultpage[$k]["name"]; ?></td>
	<td class="column2"><?php echo $newDate ?></td>
	<td class="column3 align-right">$ <?php echo $resultpage[$k]["subscription_amount"]; ?></td>
</tr>
<?php
        }
    }
}
if (isset($resultpage["perpage"])) {

    ?>
<tr>
	<td colspan="5" class="align-center"> <?php echo $resultpage["perpage"]; ?></td>
</tr>
<?php } ?>