function listViaAJAX() {
	$.ajax({
        method: "POST",
        url: "list.php",
        data: $("#frmSearch").serialize(),
    }).done(function( response ) {
		$("#table-body").html(response);
    });
}

function sortList() {
	if($("#order-type").val() == 'asc') {
		$("#order-type").val('desc');
		$(".sortable img").attr("src", "images/sort-up.svg");
	} else {
		$("#order-type").val('asc');
		$(".sortable img").attr("src", "images/sort-down.svg");
	}
	listViaAJAX();
}