<html>
<head>
	<link href="./assets/style.css" type="text/css" rel="stylesheet" />
</head>
<body>
	<h2 class="page-title">PHP Pagination with Search</h2>
	<div id="grid">
		<form name="frmSearch" id="frmSearch" method="post" action="index.php">
			<div class="search-box">
				<label>Search :</label> <input type="text" id="search"
					placeholder="name" name="filter_value" class="demoInputBox" /> <input
					type="button" name="go" class="search-form-btn" value="Search"
					onClick="listViaAJAX();"> <input type="reset"
					class="search-form-btn" value="Reset"
					onclick="window.location='index.php'">
			</div>
			<table id=mytable cellpadding="10" cellspacing="1">
				<thead>
					<tr>
						<th class="sortable"><span onClick="sortList();"><input
								type="hidden" name="order_type" id="order-type" value="asc" />Name</span>
							<img src='images/sort-down.svg' /></th>
						<th>Registered Date</th>
						<th class="align-right">Subscription Amount</th>
					</tr>
				</thead>
				<tbody id="table-body">
				<?php
    require_once __DIR__ . '/list.php';
    ?>				

				
				
				<tbody>
			
			</table>

		</form>

	</div>
</body>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"
	integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
	crossorigin="anonymous"></script>
<script src='./assets/pagination-ajax.js'></script>
</html>
