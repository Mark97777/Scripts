<?php
function perpage($count, $per_page = '5',$href) {
    $output = '';
    $paging_id = "link_perpage_box";
    if(!isset($_POST["pagination_offset"])) $_POST["pagination_offset"] = 1;
    if($per_page != 0)
        $pages  = ceil($count/$per_page);
        if($pages>1) {

            if(($_POST["pagination_offset"]-3)>0) {
                if($_POST["pagination_offset"] == 1)
                    $output = $output . '<span id=1 class="current-page">1</span>';
                    else
                        $output = $output . '<input type="hidden" name="pagination_offset" value="1" /><input type="button" class="perpage-link" value="1" onClick="listViaAJAX()" />';
            }
            if(($_POST["pagination_offset"]-3)>1) {
                $output = $output . '...';
            }

            for($i=($_POST["pagination_offset"]-2); $i<=($_POST["pagination_offset"]+2); $i++)
            {

                if($i<1) continue;
                if($i>$pages) break;
                if($_POST["pagination_offset"] == $i)
                    $output = $output . '<span id='.$i.' class="current-page" >'.$i.'</span>';
                    else
                        $output = $output . '<input type="hidden" name="pagination_offset" value="' . $i . '" /><input type="button" class="perpage-link" value="' . $i . '" onClick="listViaAJAX()" />';
            }

            if(($pages-($_POST["pagination_offset"]+2))>1) {

                $output = $output . '...';
            }

            if(($pages-($_POST["pagination_offset"]+2))>0) {

                if($_POST["pagination_offset"] == $pages)
                    $output = $output . '<span id=' . ($pages) .' class="current-page">' . ($pages) .'</span>';
                    else
                        $output = $output . '<input type="hidden" name="pagination_offset" value="' . $pages . '" /><input type="button" class="perpage-link" value="' . $pages . '" onClick="listViaAJAX()" />';

            }

        }
        return $output;
}

function showperpage($count, $per_page = 5, $href)
{

    $perpage = perpage($count, $per_page,$href);

    return $perpage;
}
?>