var mymodule = angular.module("SampleApp",[]);

/**
 * Angular Controller
 */

var Employee_list = mymodule.controller("tblController", function ($compile, $scope, $http){
    $scope.NumberOfPages = 0;
    $scope.currentPage = 1;
    $scope.paginationMaxBtn = 5;
    $scope.maxLength = 5;
    $scope.Employees={}
    $scope.error = false
    $scope.error_msg = ''
    /*
     * Get Employees
     */

    $scope.getEmployees = function(){
        var fdata = new FormData();
            fdata.append('currentPage', $scope.currentPage)
            fdata.append('limit', $scope.maxLength)
        $http.post('getEmployees.php', new URLSearchParams(fdata).toString() ,{
            headers:{
                'Content-Type' : 'application/x-www-form-urlencoded; charset=utf-8'
            }
        })
        .then(
            function (response){
                if(response.status == 200){
                    var data = response.data
                    if(!!data.employees && data.total){
                        $scope.Employees = data.employees;
                        $scope.NumberOfPages = Math.ceil(parseInt(data.total) / $scope.maxLength);

                        // Initiate Pagination
                        bs5cp_paginations.paginate();
                        document.querySelectorAll('.bootstrap5-custom-pagination').forEach(function(element){
                            element.childNodes.forEach(function(child_element){
                                $compile(child_element)($scope)
                            })
                        })

                    }else if(!!data.error){
                        $scope.error_msg = data.error
                    }else{
                        console.error(response)
                        $scope.error_msg = "Fetching Employee List failed due to some reasons."
                    }
                }else{
                    $scope.error_msg = "Fetching Employee List failed due to some reasons."
                    console.error(response)
                }
            },
            function (error){
                    $scope.error_msg = "Fetching Employee List failed due to some reasons."
                    console.error(error)
            }
        )
    }

    /**
     * Trigger Pagination
     * @param {int} page  
     */
    $scope.paginate = function(page){
        $scope.currentPage = page;
    }

    /**
     * Listen for Current Page Changes
     */
    $scope.$watch('currentPage', function(){
        $scope.getEmployees()
    })
    $scope.getEmployees()

})

