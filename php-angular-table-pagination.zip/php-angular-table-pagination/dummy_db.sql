-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 25, 2022 at 08:24 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

--
-- Database: `dummy_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `employee_list`
--

CREATE TABLE `employee_list` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee_list`
--

INSERT INTO `employee_list` (`id`, `name`, `phone`, `address`) VALUES
(1, 'Bradley Charles', '1-387-631-7773', '201-7452 Interdum Rd.'),
(2, 'Lysandra Schwartz', '1-329-483-7978', '9649 Dolor Road'),
(3, 'Whitney Moran', '(392) 138-7649', 'Ap #502-4286 Elementum Av.'),
(4, 'Flavia Adkins', '1-517-765-3895', '563-8222 At Street'),
(5, 'Vladimir Bradley', '1-436-562-8352', 'P.O. Box 170, 9079 Amet, Ave'),
(6, 'Asher Osborn', '(255) 217-5562', '332-4023 Ridiculus Street'),
(7, 'Shaine Mathews', '1-528-220-9818', 'P.O. Box 865, 3851 Dui. Road'),
(8, 'Donovan Todd', '1-615-939-1360', 'P.O. Box 637, 895 Ac, Avenue'),
(9, 'Jackson Ward', '1-305-537-3752', '199-8650 Sapien. Rd.'),
(10, 'Naida Michael', '(157) 545-9897', '502-3887 Ultrices. St.'),
(11, 'Scarlet Willis', '1-761-717-4296', '9935 A, St.'),
(12, 'Colette Carr', '1-586-832-2814', 'Ap #654-7677 Mattis Ave'),
(13, 'Macy Pena', '1-322-550-6531', '6567 Malesuada Rd.'),
(14, 'Rooney Mckinney', '(295) 257-5029', 'P.O. Box 444, 1418 Vivamus Street'),
(15, 'Denton Wilder', '1-464-768-6866', '798 Dictum St.'),
(16, 'Jin Emerson', '(295) 421-5258', '394-5031 Risus. Rd.'),
(17, 'Jack Rose', '(716) 946-1411', 'Ap #511-7704 Odio Rd.'),
(18, 'Eric Serrano', '(911) 717-7798', 'P.O. Box 760, 9708 Penatibus Road'),
(19, 'Forrest Andrews', '1-657-248-8527', '600-6646 Tellus Rd.'),
(20, 'Elijah Gregory', '(252) 814-5344', 'Ap #372-9501 Aliquet Avenue'),
(21, 'Phoebe Moses', '1-332-384-8360', '746-9767 Suspendisse St.'),
(22, 'William Peters', '(850) 847-5722', 'P.O. Box 382, 4880 Neque St.'),
(23, 'Basil Parsons', '(751) 775-5828', 'Ap #497-4995 Per Rd.'),
(24, 'Mufutau Bradley', '(935) 451-8759', '520-315 Congue, Avenue'),
(25, 'Ciaran Bradshaw', '(788) 774-8911', 'Ap #388-1102 Magna Ave');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employee_list`
--
ALTER TABLE `employee_list`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employee_list`
--
ALTER TABLE `employee_list`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;
