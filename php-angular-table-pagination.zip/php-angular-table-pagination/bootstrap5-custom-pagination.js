class bs5cp_paginations_class {
    paginate(){
        // Get Pagination Node Elements
        this.bs5cp_paginations_els = document.querySelectorAll('.bootstrap5-custom-pagination') 

        // Generate Pagination Buttons
        this.bs5cp_paginations_els.forEach(function(element, index){
            element.innerHTML = "";
            var options = {
                maxLength: parseInt(element.getAttribute('data-max-length')) || 5,
                currentPage: parseInt(element.getAttribute('data-current-page')) || 1,
                totalBtns: parseInt(element.getAttribute('data-number-of-pages')) || 1,
                maxButtons: parseInt(element.getAttribute('data-buttons-max')) || 5,
                btn_callback: element.getAttribute('data-btn-callback') || null,
                previousText: element.getAttribute('data-previous-text') || "prev",
                nextText: element.getAttribute('data-next-text') || "next"
            }

            // Button Group Parent
            var btn_group = document.createElement('div')
            btn_group.setAttribute('role','group');
            btn_group.classList.add('btn-group');
            

            //Previous Button
            var prev_btn = document.createElement('button')
            prev_btn.setAttribute('type','button');
            prev_btn.classList.add('btn', 'btn-sm', 'rounded-0', 'border');
            var prev_page = parseInt(options.currentPage) - 1;
            prev_btn.setAttribute('ng-click',`${options.btn_callback}(${prev_page})`);
            if(options.currentPage == 1)
            prev_btn.setAttribute('disabled', true)
            prev_btn.innerHTML = options.previousText
            element.appendChild(prev_btn)


            //First Page Button
            var first_btn = document.createElement('button')
                first_btn.classList.add('btn', 'btn-sm', 'rounded-0', 'border');
                first_btn.setAttribute('type','button');
                first_btn.setAttribute('ng-click',`${options.btn_callback}(1)`);
                first_btn.innerHTML = 1
                if(options.currentPage == 1)
                first_btn.classList.add('active', 'btn-primary');
                element.appendChild(first_btn)
                
                //Ellipsis Button
                var ellipsis_btn = document.createElement('button')
                    ellipsis_btn.classList.add('btn', 'btn-sm', 'rounded-0', 'border');
                    ellipsis_btn.setAttribute('type','button');
                    ellipsis_btn.setAttribute('disabled',true);
                    ellipsis_btn.innerHTML = '...'


                //Dynamic Page Buttons
                var dynamic_btn = document.createElement('button')
                    dynamic_btn.classList.add('btn', 'btn-sm', 'rounded-0', 'border');
                    dynamic_btn.setAttribute('type','button');
                if(options.currentPage > 3 && options.totalBtns > 5)
                    element.appendChild(ellipsis_btn.cloneNode(true))
                if(options.totalBtns > 5){
                    var iteratePage = parseInt(options.currentPage > 2 ? options.currentPage : 3) ;
                    for(var $i = iteratePage; $i < (iteratePage + 3); $i++){
                        var new_page_btn = dynamic_btn.cloneNode(true)
                        var num =  $i -1;
                        if((iteratePage + 1) == options.totalBtns)
                            num =  $i -2;
                        if(iteratePage == options.totalBtns)
                            num =  $i -3;
                        new_page_btn.setAttribute('ng-click',`${options.btn_callback}(${num})`);
                        new_page_btn.innerHTML = num
                        if(options.currentPage == num)
                            new_page_btn.classList.add('active', 'btn-primary');
                        element.appendChild(new_page_btn)
                    }
                }else{
                    for(var $i = 2; $i < 5; $i++){
                        var new_page_btn = dynamic_btn.cloneNode(true)
                        new_page_btn.setAttribute('ng-click',`${options.btn_callback}(${$i})`);
                        new_page_btn.innerHTML = $i
                        if(options.currentPage == $i)
                        new_page_btn.classList.add('active', 'btn-primary');
                        element.appendChild(new_page_btn)
                    }
                }
                if(options.totalBtns > 5 && ((options.totalBtns - 2) > options.currentPage)){
                    element.appendChild(ellipsis_btn.cloneNode(true))
                }

    
            //Last Page Button
            if(options.totalBtns > 1){
                var last_btn = document.createElement('button')
                    last_btn.classList.add('btn', 'btn-sm', 'rounded-0', 'border');
                    last_btn.setAttribute('type','button');
                    last_btn.setAttribute('ng-click',`${options.btn_callback}(${options.totalBtns})`);
                    last_btn.innerHTML = options.totalBtns
                    if(options.currentPage == options.totalBtns)
                    last_btn.classList.add('active', 'btn-primary');
                    element.appendChild(last_btn)
            }
            
            //Next Page Button

            var next_btn = document.createElement('button')
            next_btn.setAttribute('type','button');
            next_btn.classList.add('btn', 'btn-sm', 'rounded-0', 'border');
            var next_page = parseInt(options.currentPage) + 1;
            next_btn.setAttribute('ng-click',`${options.btn_callback}(${next_page})`);
            if(options.currentPage == options.totalBtns)
            next_btn.setAttribute('disabled', true)
            next_btn.innerHTML = options.nextText
            element.appendChild(next_btn)
    
        })
    }
}
let bs5cp_paginations = new bs5cp_paginations_class();
