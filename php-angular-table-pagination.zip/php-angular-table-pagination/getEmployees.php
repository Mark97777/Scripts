<?php 
require_once('db-connect.php');
$limit = isset($_POST['limit']) ? $_POST['limit'] : 5;
$currentPage = $offset = isset($_POST['currentPage']) ? $_POST['currentPage'] : 1;
$offset = $currentPage > 1 ? ceil(($currentPage * $limit) -$limit) : 0;
$sqlTotal = "SELECT id FROM `employee_list`";
$sql = "SELECT * FROM `employee_list` order by `name` asc LIMIT {$limit} OFFSET {$offset}";
$query = $conn->query($sql);
$queryTotal = $conn->query($sqlTotal);
$data['employees'] = $query->fetch_all(MYSQLI_ASSOC);
$data['total'] = $queryTotal->num_rows;

echo json_encode($data);
$conn->close();