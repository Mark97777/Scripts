<?php 
 
if($_SERVER['REQUEST_METHOD'] == "POST"){

    $subject = $_POST['subject'];
    $recepient = $_POST['recepient'];
    $message = "<html><body>".$_POST['message']."</body></html>";


   


    $file_dir = "uploads/";
    if(!dir($file_dir)){
        mkdir($file_dir);
    }
    if(isset($_FILES['attach_file']['tmp_name']) && !empty($_FILES['attach_file']['tmp_name'])){
        $file_name = ($_FILES['attach_file']['name']);

        /**
         * Check filename if has duplicate
         */
        $i = 0;
        while(true){
            $path = pathinfo($file_name);
            $tmp_name = $path['filename'].($i > 0 ? "_$i" : "").".".$path['extension'];
            if(is_file($file_dir.$tmp_name)){
                $i++;
            }else{
                $file_name = $tmp_name;
                break;
            }
        }

        $upload = move_uploaded_file($_FILES['attach_file']['tmp_name'], $file_dir.$file_name);
        if($upload){
            $file_path = $file_dir.$file_name;


            /**
             * Sending Mail
             */

            
            //File to attach on mail
            $attached_content = file_get_contents($file_path);
            $attached_content = chunk_split(base64_encode($attached_content));

            // a random hash will be necessary to send mixed content
		    $separator = md5(time());

            $eol = "\r\n";
        
            // Mail Main Header
            $headers = "From: Sample Mail with Attachment <info@sample.com>" . $eol;
            $headers .= "MIME-Version: 1.0" . $eol;
            $headers .= "Content-Type: multipart/alternative; boundary=\"" . $separator . "\"" . $eol;
            $headers .= "Content-Transfer-Encoding: 7bit" . $eol;
        
            // HTML Message
            $body = "--" . $separator . $eol;
            $body .= "MIME-Version: 1.0" . $eol;
            $body .= "Content-Type: text/html;charset=UTF-8" . $eol;
            $body .= "Content-Transfer-Encoding: 8bit" . $eol;
            $body .= $eol. ($message) . $eol . $eol;
        
            // Attachment
            $body .= "--" . $separator . $eol;
            $body .= "Content-Type: application/octet-stream; name=\"" . ($file_name) . "\"" . $eol;
            $body .= "Content-Transfer-Encoding: base64" . $eol;
            $body .= "Content-Disposition: attachment" . $eol;
            $body .= $attached_content . $eol;
            $body .= "--" . $separator . "--";

            try{
                // Sending mail
                mail($recepient, $subject, $body, $headers);
                echo "<script>alert('Mail has been sent successfully!'); location.replace('./');</script>";
            } catch (Exceptions $err){
                print_r($err);
            }

        }else{
            echo "<script>alert('Uploading File Failed!'); location.replace(document.referrer);</script>";
        }
    }else{
        echo "<script>alert('File Attachment is required!'); location.replace(document.referrer);</script>";
    }

}

?>