
const { createApp } = Vue

/**
 * Create Vue App to the selected Element
 */
createApp({
    /**
     * App Data
     */
    data() {
        return {
            languages: [],
            search:''
        }

    },
    /**
     * App Methods
     */
    methods:{

        /**
         * Retrieve All Data From Database using Fetch API
         */
        getLanguages(){
            fetch('getLanguages.php')
            .then(response => {
                return response.json()
            })
            .then(data => {
                this.languages = Object.values(data)
            } )
        },
        /**
         * Retrieve All Data that Name is like the Search Term From Database using Fetch API
         */
        searchLanguages(){
            var formData = new FormData();
            formData.append('search', this.search)
            fetch('getLanguages.php',{
                method:'POST',
                body: formData
            })
            .then(response => {
                return response.json()
            })
            .then(data => {
                this.languages = Object.values(data)
            } )
        }
    },
    created: function() {
        /**
         * Load All Data when app is created
         */
        this.getLanguages()
    }
}).mount('#SampleApp')