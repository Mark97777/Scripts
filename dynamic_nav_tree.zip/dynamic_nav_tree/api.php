<?php
require_once('db-connect.php');
$action = isset($_GET['action']) ? $_GET['action'] : null;

/**
 * Insert Navigation Data 
 */
function add_nav(){
    global $conn;
    $label = addslashes($conn->real_escape_string($_POST['label']));
    $title = addslashes($conn->real_escape_string($_POST['title']));
    $link = addslashes($conn->real_escape_string($_POST['link']));
    $parent_id = (is_numeric($_POST['parent_id']) && $_POST['parent_id'] > 0) ? $_POST['parent_id'] : NULL;
    $is_new_tab = isset($_POST['is_new_tab']) && $_POST['is_new_tab'] == 'on'? 1 : 0;

    $insert_sql = "INSERT INTO `page_list` (`label`, `title`, `link`, `parent_id`, `is_new_tab`) VALUES
                    ('{$label}', '$title', '$link', ".($parent_id ? $parent_id : 'NULL').", $is_new_tab)";
    $insert = $conn->query($insert_sql);
    if($insert){
        $resp['status'] = 'success';
        $resp['msg'] = 'New Navigation has been saved successfully.';
    }else{
        $resp['status'] = 'failed';
        $resp['error'] = $conn->error;
    }
    return $resp;
}

/**
 * Update Navigation Data 
 */
function update_nav(){
    global $conn;
    $id = $_POST['id'];
    $label = addslashes($conn->real_escape_string($_POST['label']));
    $title = addslashes($conn->real_escape_string($_POST['title']));
    $link = addslashes($conn->real_escape_string($_POST['link']));
    $parent_id = (is_numeric($_POST['parent_id']) && $_POST['parent_id'] > 0) ? $_POST['parent_id'] : NULL;
    $is_new_tab = isset($_POST['is_new_tab']) && $_POST['is_new_tab'] == 'on'? 1 : 0;

    $update_sql = "UPDATE `page_list` set `label` = '{$label}',
                                          `title` = '{$title}',
                                          `link` = '{$link}',
                                          `parent_id` = ".($parent_id ? $parent_id : 'NULL').",
                                          `is_new_tab` = $is_new_tab
                    where id = '{$id}'
                    ";
    $update = $conn->query($update_sql);
    if($update){
        $resp['status'] = 'success';
        $resp['msg'] = 'Navigation Details has been updated successfully.';
    }else{
        $resp['status'] = 'failed';
        $resp['error'] = $conn->error;
    }
    return $resp;
}

/**
 * Delete Navigation Data 
 */
function delete_nav(){
    global $conn;
    extract($_POST);
    $sql = "DELETE FROM `page_list` where `id` = '{$id}'";
    $delete = $conn->query($sql);
    if($delete){
        $resp['status'] = 'success';
        $resp['msg'] = 'Navigation Details has been deleted successfully.';
    }else{
        $resp['status'] = 'failed';
        $resp['error'] = $conn->error;
    }
    return $resp;

}

/**
 * Get Navigation Data 
 */
function get_nav_data(){
    global $conn;
    extract($_POST);
    $sql = "SELECT * FROM `page_list` where `id` = '{$id}'";
    $get = $conn->query($sql);
    if($get->num_rows){
        $resp['status'] = 'success';
        $resp['data'] = $get->fetch_array();
    }else{
        $resp['status'] = 'failed';
        $resp['error'] = $conn->error;
    }
    return $resp;
}

if(function_exists($action)){
    $exec = $action();
    $response = $exec;
}else{
    $response = ['status' => 'failed', 'error' => "Undefined {$action} Action"];
}
echo json_encode($response);
$conn->close();