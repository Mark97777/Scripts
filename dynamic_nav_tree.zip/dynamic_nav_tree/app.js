$(document).ready(function(){
    var formModal = $('#navFormModal')
    var navForm = $('#nav-form')
    var current_link = location.href

    /**
     * higlight active nav link
     */
    $('.nav-item[data-link="'+(current_link)+'"]').addClass('active') 

    /**
     * Open Navigation Form Modal (New)
     */

    $('#add_new_nav').click(function(){
        formModal.find('.modal-title').text('Create New Navigation')
        formModal.modal('show')
    })

    // Reset Form on modal hide
    formModal.on('hide.bs.modal', function(){
        navForm[0].reset()
        navForm.find('input:hidden').val('')
    })

     // initiate Select2
     formModal.on('shown.bs.modal', function(){
        navForm.find('[name="parent_id"]').select2({
            dropdownParent: formModal
        })
    })

    /**
     * Update Navigation Details
     */

    $('#nav-list .nav-item .edit').click(function(){
        var id = $(this).attr('data-id')
        $.ajax({
            url:'api.php?action=get_nav_data',
            data:{id:id},
            method:'POST',
            dataType:'json',
            error: (err) => {
                alert("An error occurred while fetching data.")
                console.error(err)
            },
            success: function(response){
                if(!!response.status){
                    if(response.status == 'success'){
                        $('[name="id"]').val(response.data.id)
                        $('[name="title"]').val(response.data.title)
                        $('[name="label"]').val(response.data.label)
                        $('[name="link"]').val(response.data.link)
                        if(response.data.is_new_tab == 1){
                            $('[name="is_new_tab"]').prop('checked', true)
                        }
                        if(response.data.parent_id == null || response.data.parent_id == ''){
                            response.data.parent_id = 0;
                        }
                        $('[name="parent_id"]').val(response.data.parent_id)
                        formModal.find('.modal-title').text('Edit Navigation Details')
                        formModal.modal('show')

                    }else if(response.status == 'failed'){
                        alert(response.error)
                    }else{
                        alert("An error occurred while fetching data.")
                        console.error(response)
                    }
                }else{
                    alert("An error occurred while fetching data.")
                    console.error(response)
                }
            }
        })
    })

    /**
     * Delete Navigation
     */
     $('#nav-list .nav-item .delete').click(function(){
        var id = $(this).attr('data-id')

        if(confirm(`Are you sure to delete the selected Navigation Data?`) === true){
            $.ajax({
                url:'api.php?action=delete_nav',
                data:{id:id},
                method:'POST',
                dataType:'json',
                error: (err) => {
                    alert("An error occurred while deleting data.")
                    console.error(err)
                },
                success: function(response){
                    if(!!response.status){
                        if(response.status == 'success'){
                            alert(response.msg)
                            location.reload()
                        }else if(response.status == 'failed'){
                            alert(response.error)
                        }else{
                            alert("An error occurred while deleting data.")
                            console.error(response)
                        }
                    }else{
                        alert("An error occurred while deleting data.")
                        console.error(response)
                    }
                }
            })
        }
    })
    /**
     * Submit Navigation Form
     */

    navForm.submit(function(e){
        var id = $(this).find('input[name="id"]').val()
        if(id > 0){
           var url =  'api.php?action=update_nav'
        }else{
           var url =  'api.php?action=add_nav'

        }
        e.preventDefault();
        $.ajax({
            url:url,
            method: 'POST',
            data: $(this).serialize(),
            dataType:'json',
            error: (err) => {
                alert("An error occurred while submitting the form.")
                console.error(err)
            },
            success: function(response){
                if(!!response.status){
                    if(response.status == 'success'){
                        alert(response.msg)
                        location.reload()
                    }else if(response.status == 'failed'){
                        alert(response.error)
                    }else{
                        alert("An error occurred while submitting the form.")
                        console.error(response)
                    }
                }else{
                    alert("An error occurred while submitting the form.")
                    console.error(response)
                }
            }
        })
    })

})