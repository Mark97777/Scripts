<?php 
/**
 * Defining Site URL
 */
if(!defined('site_url'))
define('site_url', 'http://localhost/dynamic_nav_tree/');


/**
 * List All Navigations
 */

$nav_sql = "SELECT * FROM `page_list` order by `label` asc";
$nav_qry = $conn->query($nav_sql);
if(!$conn->error){
    $qry_count = $nav_qry->num_rows;
    $nav_results = $nav_qry->fetch_all(MYSQLI_ASSOC);
    $nav_list_by_label = array_column($nav_results, 'label', 'id'); 
    $nav_parents = array_column($nav_results, 'parent_id'); 
    $nav_parents = array_unique($nav_parents);
    $nav_parents = array_filter($nav_parents);
}else{
    die("Query Failed! Error: ".$conn->error);
}

$nav_tree = [];

function child_nav($parent = 0){

}
foreach($nav_results as $row){
    $row['is_parent'] = 0;
   
    if( in_array($row['id'], $nav_parents) )
        $row['is_parent'] = 1;
    $nav_tree[(!is_null($row['parent_id']) ? $row['parent_id'] : 0)][$row['id']] = $row;
}

/**
 * Validating Link whether to add the site url or not
 */

function esc_link($link=""){
    if(preg_match('/^http:\/\/|^https:\/\//',$link)){
        $link = $link;
    }else{
        $link = site_url.$link;
    }
    return $link;
}

/**
 * Display Nav Child
 */
function get_child($parent_id = 0){
    global $nav_tree;
    ob_start();
    ?>
    <ul class="nav-list-child" data-parent="<?= $parent_id ?>">
    <?php if(isset($nav_tree[$parent_id])): ?>
        <?php foreach($nav_tree[$parent_id] as $nav): ?>
            <li class="nav-item" data-link="<?= esc_link($nav['link']) ?>">
                <div class="d-flex w-100">
                    <a class="col-auto flex-shrink-1 px-2 flex-grow-1 fw-bold w-100 text-decoration-none text-dark" href="<?= esc_link($nav['link']) ?>" <?= $nav['is_new_tab'] == 1 ? "target='_blank'" : '' ?> title="<?=  $nav['title'] ?>"><?=  $nav['label'] ?></a>
                    <div class="col-auto">
                        <div class="dropdown">
                            <a class="text-dark mx-3" href="#" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fa-solid fa-ellipsis-vertical"></i>
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item edit" data-id='<?= $nav['id'] ?>' href="#">Edit</a></li>
                                <li><a class="dropdown-item delete" data-id='<?= $nav['id'] ?>' href="#">Delete</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <?php 
                    if($nav['is_parent'] == 1):
                        echo get_child($nav['id']);
                    endif; 
                    ?>
            </li>
        <?php endforeach; ?>
    <?php endif; ?>
    </ul>
    <?php
    return ob_get_clean();
}
?>