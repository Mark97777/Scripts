<?php 
require_once('db-connect.php');
require_once('config.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dynamic Nav Tree - PHP</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js" integrity="sha512-naukR7I+Nk6gp7p5TMA4ycgfxaZBJ7MO5iC3Fp6ySQyKFHOGfpkSZkYVWV5R7u7cfAicxanwYQ5D1e17EfJcMA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">

    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="custom.css">

    <script src="https://code.jquery.com/jquery-3.6.1.min.js" integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <style>
        
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary bg-gradient">
        <div class="container">
            <a class="navbar-brand" href="./">Dynamic Nav Tree - PHP</a>
            <div>
                <a href="https://sourcecodester.com" class="text-light fw-bolder h6 text-decoration-none" target="_blank">SourceCodester</a>
            </div>
        </div>
    </nav>
    <div class="container px-5 my-3">
        <div class="row">
            <!-- Navigation Container -->
            <div class="col-lg-4 col-md-5 col-sm-12">
                <div class="mb-3">
                    <button class="btn btn-sm btn-primary rounded-pill px-3 mx-1" id="add_new_nav" type="button"><i class="fa-solid fa-plus-square"></i> Add New Nav</button>
                </div>
                <div class="card rounded-0">
                    <div class="card-header rounded-0">
                        <div class="card-title">
                            <h3>Navigations</h3>
                        </div>
                    </div>
                    <div class="card-body rounded-0">
                        <div class="container-fluid">
                            <ul id="nav-list">
                                <?php if(isset($nav_tree[0])): ?>
                                    <?php foreach($nav_tree[0] as $nav): ?>
                                        <li class="nav-item" data-link="<?= esc_link($nav['link']) ?>">
                                            <div class="d-flex w-100">
                                                <a class="col-auto flex-shrink-1 flex-grow-1 fw-bold w-100 text-decoration-none text-dark px-2" href="<?= esc_link($nav['link']) ?>" <?= $nav['is_new_tab'] == 1 ? "target='_blank'" : '' ?> title="<?=  $nav['title'] ?>"><?=  $nav['label'] ?></a>
                                                <div class="col-auto">
                                                    <div class="dropdown">
                                                        <a class="text-dark mx-3" href="#" data-bs-toggle="dropdown" aria-expanded="false">
                                                            <i class="fa-solid fa-ellipsis-vertical"></i>
                                                        </a>
                                                        <ul class="dropdown-menu">
                                                            <li><a class="dropdown-item edit" data-id='<?= $nav['id'] ?>' href="#">Edit</a></li>
                                                            <li><a class="dropdown-item delete" data-id='<?= $nav['id'] ?>' href="#">Delete</a></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php 
                                                if($nav['is_parent'] == 1):
                                                    echo get_child($nav['id']);
                                                endif; 
                                             ?>
                                        </li>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Navigation Container -->
            <!-- Page Content Container -->
            <div class="col-lg-8 col-md-7 col-sm-12 mt-4 pt-4">
                <div class="container-fluid">
                    <div class="card rounded-0 shadow">
                        <div class="card-header">
                            <div class="card-title">Page Content</div>
                        </div>
                        <div class="card-body">
                            <div class="container-fluid">
                                <p>You are currently browsing the <a href="#"><b><?= (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http")."://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ?></b></a> page.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End of Page Content Container -->
        </div>
    </div>
    <!-- Folder Form Modal -->
    <div class="modal fade" id="navFormModal" data-bs-backdrop="static" aria-labelledby="navFormModal" aria-hidden="true" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable rounded-0">
            <div class="modal-content rounded-0">
                <div class="modal-header rounded-0">
                    <h1 class="modal-title fs-5"></h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body rounded-0">
                    <div class="container-fluid">
                        <form action="" id="nav-form">
                            <input type="hidden" name="id">
                            <div class="mb-3">
                                <label for="label" class="form-label">Navigation Label</label>
                                <input type="text" class="form-control rounded-0" name="label" id="label" required="required">
                            </div>
                            <div class="mb-3">
                                <label for="title" class="form-label">Title Attribute</label>
                                <input type="text" class="form-control rounded-0" name="title" id="title" required="required">
                            </div>
                            <div class="mb-3">
                                <label for="link" class="form-label">Page Link</label>
                                <input type="text" class="form-control rounded-0" name="link" id="link" required="required">
                            </div>
                            <div class="mb-3">
                                <label for="parent_id" class="form-label">Parent Folder</label>
                                <select name="parent_id" id="parent_id" class="form-select rounded-0" required>
                                    <option value="0">Root</option>
                                    <?php foreach($nav_list_by_label as $nav_id => $nav_label): ?>
                                        <option value="<?= $nav_id ?>"><?= $nav_label ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="is_new_tab" id="is_new_tab">
                                    <label class="form-check-label" for="is_new_tab">
                                        Open in New Tab/Window
                                    </label>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" form="nav-form" class="btn btn-primary btn-sm rounded-0">Save Navigation</button>
                    <button type="button" class="btn btn-secondary btn-sm rounded-0" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <!-- End of Folder Form Modal -->

    <script src="app.js" ></script>

</body>
<?php 
if(isset($conn)){
    $conn->close();
}
?>
</html>