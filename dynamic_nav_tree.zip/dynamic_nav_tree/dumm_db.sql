-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 10, 2022 at 07:34 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

--
-- Database: `dummy_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `page_list`
--

CREATE TABLE `page_list` (
  `id` int(30) NOT NULL,
  `label` varchar(250) NOT NULL,
  `link` text NOT NULL,
  `title` text NOT NULL,
  `parent_id` int(30) DEFAULT NULL,
  `is_new_tab` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0= no , 1= yes',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `page_list`
--

INSERT INTO `page_list` (`id`, `label`, `link`, `title`, `parent_id`, `is_new_tab`, `created_at`, `updated_at`) VALUES
(1, 'Home', '?page=home', 'Home', NULL, 0, '2022-11-10 11:01:00', '2022-11-10 11:01:21'),
(2, 'Page 1', '?page=main_nav_1', 'Sample Navigation Page #1', NULL, 0, '2022-11-10 11:02:51', NULL),
(3, 'Page 1.1', '?page=main_nav_1_1', 'Page 1.1', 2, 0, '2022-11-10 11:03:33', NULL),
(4, 'Page 1.1.1', '?page=main_nav_1_1_1', 'Page 1.1.1', 3, 0, '2022-11-10 11:21:50', NULL),
(5, 'Page 1.2', '?page=main_nav_1_2', 'Page 1.2', 2, 0, '2022-11-10 11:58:24', NULL),
(6, 'Page 1.1.2', '?page=main_nav_1_1_2', 'Page 1.1.2', 3, 0, '2022-11-10 13:10:45', NULL),
(7, 'External', 'https://www.sourcecodester.com/', 'External Link', NULL, 1, '2022-11-10 13:53:33', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `page_list`
--
ALTER TABLE `page_list`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `page_list`
--
ALTER TABLE `page_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;
