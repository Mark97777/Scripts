var liveClockInvetrval;
$(document).ready(function(){
    // Live Clock
    liveClockInvetrval = setInterval(function(){
        var current_date = new Date().toLocaleString('en-US', { timeZone: 'Asia/Manila'});
        var new_date = new Date(current_date)

        var h = new_date.getHours();
        var m = new_date.getMinutes();
        var s = new_date.getSeconds();
        var am_pm = h > 12 ? "AM" : "PM";

        h = h > 12 ? h - 12 : (h == 0? 12: h);
        $('#CurrentTime').text(`${h.toString().padStart(2, 0)}:${m.toString().padStart(2, 0)}:${s.toString().padStart(2, 0)} ${am_pm}`)
    },500)

})