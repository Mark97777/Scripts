<?php
date_default_timezone_set("Asia/Manila");

function get_timeago($timestamp=""){
    // Check if time stamp is valid
    if(empty($timestamp) && !is_numeric($timestamp) && $timestamp < 0)
    return "Invalid Date and Time Value";

    // Current Timestamp
    $current_time = strtotime('now');
    // Getting the difference beteween Current timestamp and given timestamp
    $diff = $current_time - $timestamp;
    // Timeago or timestamp difference in seconds
    $ta_seconds = $diff;
    
    
    /**
     * Timestamp Difference (s) Convertions
     */

        /**Getting the difference by minute(s) 
         * timestamp difference / 60
         */
        $minutes = round($ta_seconds / 60); 
        /**Getting the difference by hour(s) 
         * timestamp difference / ( 60 * 60)
         */
        $hours   = round($ta_seconds / 3600);
        /**Getting the difference by day(s) 
         * timestamp difference / ( 24 * 60 * 60)
         */
        $days    = round($ta_seconds / 86400);
        /**Getting the difference by week(s) 
        * timestamp difference / ( 7 * 24 * 60 * 60)
        */
        $weeks   = round($ta_seconds / 604800);
        /**Getting the difference by month(s) 
        * timestamp difference / ( ( ( 365 + 365 + 365 + 365 + 366 ) / 5 / 12 ) * 24 * 60 *60 )
        */
        $months  = round($ta_seconds / 2629440);
        /**Getting the difference by year(s) 
        * timestamp difference / ( ( ( 365 + 365 + 365 + 365 + 366 ) / 5 ) * 24 * 60 *60 )
        */
        $years   = round($ta_seconds / 31553280); 

        
        /**
         * Return Timeago
         */
        if( $ta_seconds < 60 ){
            if( $ta_seconds == 1)
                return "Just Now";
            else
                return "{$ta_seconds} sec. ago";
        }elseif($minutes < 60){
            if( $minutes == 1 )
                return "A minute ago";
            else
                return "{$minutes} min. ago";
        }elseif( $hours < 24 ){
            if( $hours == 1 )
                return "An Hour ago";
            else
                return "{$hours} hr. ago";
        }elseif( $days < 7 ){
            if( $days == 1 )
                return "A day ago";
            else
                return "{$days} days ago";
        }elseif( $weeks < 4 ){
            if( $weeks == 1 )
                return "A week ago";
            else
                return "{$weeks} weeks ago";
        }elseif( $months < 12 ){
            if( $months == 1 )
                return "A month ago";
            else
                return "{$months} months ago";
        }elseif( $years > 0 ){
            if( $years == 1 )
                return "A year ago";
            else
                return "{$years} years ago";
        }elseif($ta_seconds <= -1){
            return "Future/Scheduled";
        }else{
                return "{$weeks} weeks ago";
        }
}

