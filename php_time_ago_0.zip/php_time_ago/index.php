<?php 
require_once("time_ago_func.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Time Ago Function</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.6.1.min.js" integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js" integrity="sha384-IDwe1+LCz02ROU9k972gdyvl+AESN10+x7tBKgc9I5HFtuNz0wWnPclzo6p9vxnk" crossorigin="anonymous"></script>
    <style>
        html, body{
            min-height:calc(100%);
            width: calc(100%);
        }
        body{
            min-height: 100vh;
            width: 100vw;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }
    </style>
</head>
<body class="bg-light bg-gradient">
    <div class="container-fluid w-100">
        <div class="col-lg-7 col-md-9 col-sm-12 mx-auto">
            <h1 class="text-center fw-bolder my-4">Creating a Time Ago Function in PHP like some famous Social Networking Sites</h1>
            <div class="d-flex justify-content-center">
                <hr class="col-4">
            </div>
        </div>
        <div class="card rounded-0 shadow col-lg-5 col-md-7 col-sm-12 mx-auto">
            <div class="card-body">
                <div class="container-fluid">
                    <form action="" id="sample-form" method = "POST">
                        <div class="mb-3" id="progress-holder">
                            <div id="CurrentTime" class="h2 fw-bold text-center">
                                --:--:-- --
                            </div>
                            <div class="text-center h4 text-muted">Philippine Standard Time</div>
                        </div>
                        <div class="mb-3">
                            <label for="datetime" class="form-label">Select DateTime</label>
                            <input class="form-control" type="datetime-local" name="datetime"  id="datetime" value="<?= isset($_POST['datetime']) ? $_POST['datetime'] : '' ?>" required>
                        </div>
                        <div class="mb-3 d-grid">
                            <button class="btn btn-sm rounded-pill btn-primary btn-block" type="submit">Submit</button>
                        </div>
                    </form>
                    <div class="text-bg-dark px-2 py-3">
                        <?php if($_SERVER['REQUEST_METHOD'] == "POST"): ?>
                            <dl class="row">
                                <dt class="col-auto pe-2">Date and Time:</dt>
                                <dd class="col-auto flex-shrink-1 flex-grow-1"><?= date("F d, Y g:i:s A", strtotime($_POST['datetime'])) ?></dd>
                            </dl>
                            <dl class="row">
                                <dt class="col-auto pe-2">Conversion:</dt>
                                <dd class="col-auto flex-shrink-1 flex-grow-1"><?= get_timeago(strtotime($_POST['datetime'])) ?></dd>
                            </dl>
                        <?php else: ?>
                            <div class="text-center">Select Date and Time First.</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

<script src="./app.js"></script>
</html>

