<?php
require_once("db-connect.php");
if($_SERVER['REQUEST_METHOD'] == "POST"){
    extract($_POST);
    $grr = $_POST['g-recaptcha-response'];
    if(empty($grr)){
        $err_captcha = "Kindly check reCaptcha Checkbox before submitting the form.";
    }else{
        /**
         * Validate Google reCaptcha
         */ 

        //  Secret key
        $secret = "your-secret-key";

        // Get verification response

        $http_query = http_build_query(["response" => $grr, "secret" => $secret]);

        $ch = curl_init("https://www.google.com/recaptcha/api/siteverify?".$http_query);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        curl_close($ch);

        $response = (array) json_decode($result);
        if(isset($response['success']) && !empty($response['success'])){
            $sql = "INSERT INTO `members` (`first_name`, `middle_name`, `last_name`, `email`, `contact`)
                    VALUES ('{$first_name}', '{$middle_name}', '{$last_name}', '{$email}', '{$contact}')";
            $insert = $conn->query($sql);
            if($insert){
                $_SESSION['success_msg'] = "Data has been saved successfully";
                header('location: ./');
                exit;
            }else{
                $error_msg = "There's an error occurred while saving the data";
            }
        }else{
            $err_captcha = "reCaptcha Validation Failed. <br>";
            if(isset($response['error-codes']) && count($response['error-codes'])){
                $err_captcha .= "<ul>";
                foreach($response['error-codes'] as $error){
                    $err_captcha .= "<li>{$error}</li>";  
                }
                $err_captcha .= "</ul>";  
            }
            $err_captcha = "Please check the checkbox.";
        }
    }
}