function changeColor(id){
	document.getElementById("box").style.backgroundColor=id;
}