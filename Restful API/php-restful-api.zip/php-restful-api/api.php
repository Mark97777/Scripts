<?php 
header("Content-Type:application/json");
require_once('db-connect.php');

class API {
    public $db;
    function __construct(){
        global $conn;
        $this->db = $conn;
    }

    /**
     * Verify Token
     */
    
    function verify_token($token=""){
        $validity = false;
        if(!empty($token)){
            $check_token = $this->db->query("SELECT id FROM `token_list` where `token` = '{$token}'")->num_rows;
            if($check_token > 0)
            return true;
        }
    }

    /**
     * POST Request
     * - insert data to database
     */

    function new_language(){
        if(isset($_SERVER['REQUEST_METHOD']) == "POST"){
            $data  = "";
            foreach($_POST as $k => $v){
                if(!is_numeric($v))
                $v = addslashes($this->db->real_escape_string($v));

                if(!empty($data)) $data .= ", ";
                $data .= " `{$k}` = '{$v}'";
            }

            $insert_sql = "INSERT INTO `programming_languages` set {$data}";
            // return ['sql' => $insert_sql, 'POST' => $_REQUEST];
            $insert = $this->db->query($insert_sql);
            if($insert){
                $resp['status'] = 'success';
                $resp['message'] = 'New Data has been saved successfully.';
                $id = $this->db->insert_id;
                $get = $this->db->query("SELECT * FROM `programming_languages` where `id` = '{$id}'")->fetch_assoc();
                $resp['result'] = $get;
            }else{
                $resp['status'] = 'failed';
                $resp['error'] = $this->db->error;
            }
            return $resp;

        }else{
            $resp['status'] = 'failed';
            $resp['error'] = "This API Method must contain valid POST Data";
            return $resp;
        }
    }

    /**
     * POST Request
     * - List all Table data to database
     */

    function get_languages(){
        $sql = "SELECT * FROM `programming_languages`";
        $query = $this->db->query($sql);
        $resp['status'] = 'success';
        $resp['num_rows'] = $query->num_rows;
        $resp['result'] = $query->fetch_all(MYSQLI_ASSOC);
        return $resp;
    }
    /**
     * POST Request
     * - List all Table data to database
     */

    function get_language_by_id(){
        extract($_GET);
        if(!isset($id)){
            $resp['status'] = 'failed';
            $resp['error'] = "This API Method requires an ID Parameter";
        }else{
            if(!is_numeric($id)){
                $resp['status'] = 'failed';
                $resp['error'] = "ID must be an integer.";
            }else{
                $sql = "SELECT * FROM `programming_languages` where id = {$id}";
                $query = $this->db->query($sql);
                if($query->num_rows > 0){
                    $resp['status'] = 'success';
                    $resp['result'] = $query->fetch_assoc();
                }else{
                    $resp['status'] = 'failed';
                    $resp['error'] = "Invalid given ID.";
                }
            }
            
        }
        return $resp;

    }

    /**
     * POST Request
     * - Update data from database
     */

    function update_language(){
        if(isset($_SERVER['REQUEST_METHOD']) == "POST"){
            $id = $_POST['id'];
            if(!isset($id)){
                $resp['status'] = 'failed';
                $resp['error'] = "This API Method requires an ID Parameter";
            }else{

                $data  = "";
                foreach($_POST as $k => $v){
                    if($k == 'id')
                    continue;
                    if(!is_numeric($v))
                    $v = addslashes($this->db->real_escape_string($v));

                    if(!empty($data)) $data .= ", ";
                    $data .= " `{$k}` = '{$v}'";
                }

                $update_sql = "UPDATE `programming_languages` set {$data} where id = '{$id}'";
                // return ['sql' => $update_sql, 'POST' => $_REQUEST];
                $update = $this->db->query($update_sql);
                if($update){
                    $resp['status'] = 'success';
                    $resp['message'] = 'Data has been saved successfully.';
                    $get = $this->db->query("SELECT * FROM `programming_languages` where `id` = '{$id}'")->fetch_assoc();
                    $resp['result'] = $get;
                }else{
                    $resp['status'] = 'failed';
                    $resp['error'] = $this->db->error;
                }
            }
        }else{
            $resp['status'] = 'failed';
            $resp['error'] = "This API Method must contain valid POST Data";
        }
        return $resp;
    }

    /**
     * POST Request
     * - Delete data from database
     */

    function delete_language(){
       if($_SERVER['REQUEST_METHOD'] == "DELETE"){
        if(!isset($_GET['id'])){
            $resp['status'] = "error";
            $resp['error'] = "The request must contain an ID Paramater.";
        }else{
            $id = $_GET['id'];
            if(!is_numeric($id)){
                $resp['status'] = "error";
                $resp['error'] = "The ID Parameter must be an integer.";
            }else{
                $delete = $this->db->query("DELETE FROM `programming_languages` where `id` = {$id}");
                if($delete){
                    $resp['status'] = 'success';
                    $resp['message'] = "Programming Language with the #{$id} ID has been deleted successfully";
                }else{
                    $resp['status'] = "error";
                    $resp['error'] = "Deleting Data from Database Failed! Error:". $this->db->error;
                }
            }
        }
       }else{
        $resp['status'] = "error";
        $resp['error'] = "The request method is invalid.";
       }
       return $resp;
    }
    
    function __destruct(){
        $this->db->close();
    }
}
$api = new API();
$action = isset($_GET['action']) ? $_GET['action'] : '';

/**
 * Get headers
 */
$headers = null;
if (isset($_SERVER['Authorization'])) {
    $headers = trim($_SERVER["Authorization"]);
}
else if (isset($_SERVER['HTTP_AUTHORIZATION'])) { //Nginx or fast CGI
    $headers = trim($_SERVER["HTTP_AUTHORIZATION"]);
} elseif (function_exists('apache_request_headers')) {
    $requestHeaders = apache_request_headers();
    // Server-side fix for bug in old Android versions (a nice side-effect of this fix means we don't care about capitalization for Authorization)
    $requestHeaders = array_combine(array_map('ucwords', array_keys($requestHeaders)), array_values($requestHeaders));
    //print_r($requestHeaders);
    if (isset($requestHeaders['Authorization'])) {
        $headers = trim($requestHeaders['Authorization']);
    }
}

/**
 * Check if token has provided
 */
$api_key = null;
if(preg_match('/Bearer/i', $headers)){
    $bearer_count = preg_match_all('/Bearer\s(.*)/i',$headers, $bearer_matches);
    if(isset($bearer_matches[1][0]))
    $api_key = trim($bearer_matches[1][0]);
}
if(!is_null($api_key) && !empty($api_key)){
    $verify_api = $api->verify_token($api_key);
    if(!$verify_api){
        echo json_encode([
            'status' => 'failed',
            'error' => "API token is Invalid."
        ]);
        exit;
    }
}else{
    echo json_encode([
        'status' => 'failed',
        'error' => "API Token is Required."
    ]);
    exit;
}
if(method_exists($api, $action)){
    $exec = $api->$action();
    echo json_encode($exec);
}else{
    echo json_encode([
        'status' => 'failed',
        'error' => "API [{$action}] Method does not exists."
    ]);
}
?>