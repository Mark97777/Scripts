<?php

    /**
     * Example Function to Execute
     */
    function example($param1 = '', $param2=[]){
        return json_encode(["parameter1" => $param1, "parameter2" => $param2]);
        exit;
    }

    /**
     * Example Function Execution using the HTTP Request
     */
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        echo example($_POST['param1'], $_POST['param2']);
        exit;
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP - JS | Execute PHP Script in JS</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.6.1.min.js" integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
    <style>
        html, body{
            min-height:100%;
            width:100%;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-warning bg-gradient">
        <div class="container">
            <a class="navbar-brand" href="./">PHP - JS | Execute PHP Script in JS</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="./">Home</a>
                    </li>
                </ul>
            </div>
            <div>
                <a href="https://sourcecodester.com" class="text-light fw-bolder h6 text-decoration-none" target="_blank">SourceCodester</a>
            </div>
        </div>
    </nav>
    <div class="container-fluid px-5 my-3 h-75">
        <div class="col-lg-10 col-md-11 col-sm-12 mx-auto my-5" >
            <div class="card rounded-0 shadow">
                <div class="card-body">
                    <div class="container-fluid">
                        <div class="row justify-content-center">
                            <button class="btn btn-primary btn-lg rounded-pill col-lg-3" type="button" id="testButton1">Direct PHP Exec</button>
                            <button class="btn btn-warning btn-lg rounded-pill col-lg-3" type="button" id="testButton2">PHP Exec using Fetch API</button>
                            <button class="btn btn-success btn-lg rounded-pill col-lg-3" type="button" id="testButton3">PHP Exec using Ajax</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
<script>
    /**
     * Direct PHP Exection in JS 
     *  - only works when the paramaters are static
     */
    document.getElementById('testButton1').addEventListener('click', function(e){
        var php_func_exec1 = <?= example('1', ['test' => 'Hello World!']) ?>;
        console.log(php_func_exec1);
    })

    /**
     * PHP Exection in JS using Fetch API 
     *  - works when the paramaters are static or dynamic
     */
    document.getElementById('testButton2').addEventListener('click', function(e){
        var param1 = 'This a sample Execution using JS Fetch API',
            param2 = `{"a" : "Lorem", "b" : "Ipsum"}`
        
        var form = new FormData();
                form.append('param1', param1)
                form.append('param2', param2)

            fetch('index.php',{
                method:'POST',
                body: form,
            }).then(response => {
                return response.json()
            }).then(data => {
                console.log(data.parameter1)
                console.log($.parseJSON(data.parameter2))
            })

    })


    /**
     * PHP Exection in JS using Ajax of jQuery
     *  - works when the paramaters are static or dynamic
     */
    document.getElementById('testButton3').addEventListener('click', function(e){
        var param1 = 'This a sample Execution using JS jQuery Ajax',
            param2 = `{"a" : "Lorem", "b" : "Ipsum"}`
        
        $.ajax({
            url:"index.php",
            method:'POST',
            data: {param1:param1, param2: param2},
            dataType:'json',
            error: error => {
                console.error(error)
            },
            success:function(response){
                console.log(response.parameter1)
                console.log($.parseJSON(response.parameter2))
            }
        })

    })
</script>
</html>