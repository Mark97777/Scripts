function rem(){
	const text=document.getElementById("text").innerHTML;
	
	
	const remPunc = text.replace(/[.,\/#!$%"\^&\*;:{}=\-_`~()]/g, "").replace(/\s{2,}/g, " ");
	
	document.getElementById("text").innerHTML=remPunc;

}

function reset(){
	window.location="index.html";
}